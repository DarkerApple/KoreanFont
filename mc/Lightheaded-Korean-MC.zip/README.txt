Lightheaded Minecraft resource pack
Drop this zip into .minecraft/resourcepacks and enable it in
Options > Resource Packs. Requires Java Edition 1.20.3+
(TTF + reference font providers).
